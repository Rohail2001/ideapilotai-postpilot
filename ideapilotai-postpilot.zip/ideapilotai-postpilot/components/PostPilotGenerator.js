\
import React, { useState } from 'react'

export default function PostPilotGenerator() {
  const [businessName, setBusinessName] = useState('')
  const [businessType, setBusinessType] = useState('Restaurant')
  const [tone, setTone] = useState('Friendly')
  const [goal, setGoal] = useState('Engagement')
  const [audience, setAudience] = useState('Local homeowners, 25-45')
  const [products, setProducts] = useState('Pool mosaic installation, Pool cleaning, Design consult')
  const [frequency, setFrequency] = useState('3')
  const [platforms, setPlatforms] = useState(['Instagram'])
  const [loading, setLoading] = useState(false)
  const [calendar, setCalendar] = useState([])
  const [error, setError] = useState(null)

  function togglePlatform(p) {
    setPlatforms(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p])
  }

  async function handleGenerate(e) {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setCalendar([])
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessName, businessType, tone, goal, audience, products, frequency: Number(frequency), platforms
        })
      })
      if (!res.ok) throw new Error('Server error')
      const data = await res.json()
      setCalendar(data.calendar || [])
      if((data.calendar || []).length === 0 && data.raw){
        setError('Model returned non-JSON response. Check server logs.')
      }
    } catch (err) {
      console.error(err)
      setError(err.message || 'An error occurred')
    } finally {
      setLoading(false)
    }
  }

  function downloadCSV() {
    if (!calendar.length) return
    const headers = ['date','platform','postType','caption','cta','imagePrompt','hashtags']
    const rows = calendar.map(r => headers.map(h => JSON.stringify(r[h] || '').replace(/\\"/g, '"')))
    const csv = [headers.join(',')].concat(rows.map(r => r.join(','))).join('\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${businessName || 'ideapilot'}-calendar.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  function copyAllCaptions() {
    if (!calendar.length) return
    const text = calendar.map((r,i)=> `Day ${i+1} (${r.date}) [${r.platform}] - ${r.caption}\nCTA: ${r.cta}\nHashtags: ${r.hashtags}\n`).join('\n')
    navigator.clipboard.writeText(text)
      .then(()=> alert('Captions copied to clipboard'))
      .catch(()=> alert('Unable to copy'))
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">IdeaPilotAI — AI Social Media Planner (MVP)</h1>
      <form onSubmit={handleGenerate} className="grid grid-cols-1 gap-4 bg-white p-6 rounded shadow">
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium">Business name</label>
            <input value={businessName} onChange={e=>setBusinessName(e.target.value)} className="mt-1 block w-full rounded border p-2" placeholder="e.g., Mosaic Pools" />
          </div>
          <div>
            <label className="block text-sm font-medium">Business type</label>
            <select value={businessType} onChange={e=>setBusinessType(e.target.value)} className="mt-1 block w-full rounded border p-2">
              <option>Restaurant</option>
              <option>Cleaning Service</option>
              <option>Salon</option>
              <option>SaaS</option>
              <option>eCommerce</option>
              <option>Real Estate</option>
              <option>Construction</option>
            </select>
          </div>
        </div>

        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium">Tone</label>
            <select value={tone} onChange={e=>setTone(e.target.value)} className="mt-1 block w-full rounded border p-2">
              <option>Friendly</option>
              <option>Professional</option>
              <option>Playful</option>
              <option>Luxury</option>
              <option>Direct</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium">Primary goal</label>
            <select value={goal} onChange={e=>setGoal(e.target.value)} className="mt-1 block w-full rounded border p-2">
              <option>Engagement</option>
              <option>Sales</option>
              <option>Awareness</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium">Posts per week</label>
            <select value={frequency} onChange={e=>setFrequency(e.target.value)} className="mt-1 block w-full rounded border p-2">
              <option value="3">3</option>
              <option value="5">5</option>
              <option value="7">7</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium">Target audience</label>
          <input value={audience} onChange={e=>setAudience(e.target.value)} className="mt-1 block w-full rounded border p-2" placeholder="e.g., homeowners, 25-45, Pakistan" />
        </div>

        <div>
          <label className="block text-sm font-medium">Top 3 products / services (comma separated)</label>
          <input value={products} onChange={e=>setProducts(e.target.value)} className="mt-1 block w-full rounded border p-2" placeholder="e.g., Pool mosaic installation, Cleaning, Design consult" />
        </div>

        <div>
          <label className="block text-sm font-medium">Platforms</label>
          <div className="flex gap-4 mt-2">
            {['Instagram','Facebook','LinkedIn','TikTok'].map(p=> (
              <label key={p} className="inline-flex items-center gap-2">
                <input type="checkbox" checked={platforms.includes(p)} onChange={()=>togglePlatform(p)} />
                <span className="ml-1">{p}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="flex gap-3">
          <button type="submit" disabled={loading} className="px-4 py-2 bg-blue-600 text-white rounded">{loading? 'Generating...' : 'Generate 30-day calendar'}</button>
          <button type="button" onClick={downloadCSV} className="px-4 py-2 bg-gray-100 rounded">Export CSV</button>
          <button type="button" onClick={copyAllCaptions} className="px-4 py-2 bg-gray-100 rounded">Copy captions</button>
        </div>

        {error && <div className="text-red-600">{error}</div>}
      </form>

      <div className="mt-6">
        <h2 className="text-2xl font-semibold">Preview Calendar</h2>
        {!calendar.length && <div className="mt-3 text-sm text-gray-500">No calendar yet. Click generate to create a 30-day plan.</div>}

        <div className="grid gap-4 mt-4">
          {calendar.map((day, idx) => (
            <div key={idx} className="p-4 border rounded bg-white">
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-sm text-gray-500">Day {idx+1} • {day.date} • {day.platform}</div>
                  <div className="font-medium mt-1">{day.postType} — {day.caption}</div>
                </div>
                <div className="text-sm text-gray-600">CTA: {day.cta}</div>
              </div>
              <div className="mt-2 text-xs text-gray-500">Image prompt: {day.imagePrompt}</div>
              <div className="mt-1 text-xs text-gray-500">Hashtags: {day.hashtags}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
