# IdeaPilotAI — AI Social Media Planner (MVP)

This is a deployable Next.js project (MVP) that generates a 30-day social media calendar using OpenAI.

## Quick start (deploy on Vercel)

1. Create a GitHub repository and push the project files (or upload the zip).
2. Create a free account on https://vercel.com and connect your GitHub repo (or import the ZIP).
3. In Vercel project settings, add environment variable `OPENAI_API_KEY` with your OpenAI API key.
4. Deploy the project from Vercel — it will build automatically.
5. Open the deployed site and test the generator.

## Local development

1. Copy `.env.example` to `.env.local` and add your OpenAI key.
2. Install dependencies: `npm install`.
3. Run dev server: `npm run dev`.

## Notes

- Do NOT share your OpenAI API key publicly.
- After deployment, consider adding Stripe for paid plans and Supabase for auth.
