import { NextResponse } from 'next/server'
import OpenAI from 'openai'

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

export async function POST(req) {
  try {
    const body = await req.json()
    const { businessName, businessType, tone, goal, audience, products, frequency, platforms } = body

    const prompt = buildPrompt({ businessName, businessType, tone, goal, audience, products, frequency, platforms })

    const resp = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are IdeaPilotAI, an expert social media strategist. Produce a JSON array named calendar with 30 items. Fields: date (YYYY-MM-DD), platform, postType, caption, cta, imagePrompt, hashtags.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.35,
      max_tokens: 1900
    })

    const text = resp.choices[0].message.content

    try {
      const payload = JSON.parse(text)
      return NextResponse.json(payload)
    } catch (err) {
      return NextResponse.json({ calendar: [], raw: text })
    }
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}

function buildPrompt(inputs) {
  const platformsText = (inputs.platforms || ['Instagram']).join(', ')
  return `Business name: ${inputs.businessName || 'Unnamed Business'}\nType: ${inputs.businessType}\nTone: ${inputs.tone}\nGoal: ${inputs.goal}\nAudience: ${inputs.audience}\nProducts: ${inputs.products}\nFrequency per week: ${inputs.frequency}\nPlatforms: ${platformsText}\n\nGenerate a 30-day posting calendar for the business above. Output exact JSON only, in this format:\n{ "calendar": [ { "date":"YYYY-MM-DD", "platform":"Instagram", "postType":"Image/Carousel/Reel", "caption":"...", "cta":"...", "imagePrompt":"...", "hashtags":"#tag1 #tag2" }, ... ] }\n\nRules: Keep captions under 280 characters when possible, vary post types, include clear CTAs, and ensure image prompts work for Canva or Midjourney. Use the provided tone and audience.`
}
