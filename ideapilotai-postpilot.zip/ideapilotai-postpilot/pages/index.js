import Head from 'next/head'
import PostPilotGenerator from '../components/PostPilotGenerator'

export default function Home() {
  return (
    <>
      <Head>
        <title>IdeaPilotAI — AI Social Media Planner</title>
        <meta name="description" content="Generate a 30-day social media calendar in seconds" />
      </Head>
      <main className="min-h-screen bg-gray-50 p-6">
        <PostPilotGenerator />
      </main>
    </>
  )
}
